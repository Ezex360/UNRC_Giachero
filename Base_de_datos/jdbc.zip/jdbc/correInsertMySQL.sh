java -classpath ".:mysql-connector-java-5.0.8-bin.jar" InsertMySQL
